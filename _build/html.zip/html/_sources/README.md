# StealThisCode
Python code snippets for students to use, repurpose and explore. Steal it all.
